
#!/bin/sh
#Version: 21
#Buildtime: 19-07-2021 07:56:43
Application-name: gcalendar
java -jar gcalendar-21.jar $1 $2
