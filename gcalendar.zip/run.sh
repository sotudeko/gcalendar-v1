
#!/bin/sh
#Version: 1.4
#Buildtime: 19-07-2021 07:53:06
Application-name: gcalendar
java -jar gcalendar-1.4.jar $1 $2
