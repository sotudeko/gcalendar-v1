
#!/bin/sh
#Version: 1.4
#Buildtime: 03-10-2020 10:44:59
Application-name: gcalendar
java -jar gcalendar-1.4.jar $1 $2
