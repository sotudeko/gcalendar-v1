
#!/bin/sh
#Version: 1.3
#Buildtime: 12-09-2020 23:10:42
Application-name: gcalendar
java -jar gcalendar.jar $1 $2
